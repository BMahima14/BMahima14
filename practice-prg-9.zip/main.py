def count_spaces(S):
    return S.count(' ')

# Example usage
S =input()
space_count = count_spaces(S)
print(space_count)

